typedef void (^SPTVoidBlock)();
typedef void (^SPTAsyncBlock)(void (^)());
typedef void (^SPTDictionaryBlock)(NSDictionary *dictionary);
