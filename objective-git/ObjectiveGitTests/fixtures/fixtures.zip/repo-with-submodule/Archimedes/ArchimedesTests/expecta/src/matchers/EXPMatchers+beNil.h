#import "Expecta.h"

EXPMatcherInterface(beNil, (void));

#define beNull beNil
