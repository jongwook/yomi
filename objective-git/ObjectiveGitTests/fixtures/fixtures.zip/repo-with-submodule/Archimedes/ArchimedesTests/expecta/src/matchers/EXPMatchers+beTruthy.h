#import "Expecta.h"

EXPMatcherInterface(beTruthy, (void));
