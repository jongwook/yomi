#import "Expecta.h"

EXPMatcherInterface(beSubclassOf, (Class expected));

#define beASubclassOf beSubclassOf
