#import "Fixtures.h"

@implementation Foo; @end
@implementation Bar; @end
@implementation Baz; @end
