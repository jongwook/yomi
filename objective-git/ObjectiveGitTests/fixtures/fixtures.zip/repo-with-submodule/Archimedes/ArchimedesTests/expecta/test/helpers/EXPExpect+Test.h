#import "TestHelper.h"

@interface EXPExpect (Test)

@property (nonatomic, readonly) EXPExpect *test;

@end
